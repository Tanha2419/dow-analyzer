#!/usr/bin/env bash
cd "$(dirname "$0")"
exec .venv/bin/python dow_analyzer.py "$@"
