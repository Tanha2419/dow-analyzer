/**
 * پشتیبان ژورنال معاملاتی در گوگل شیت
 * ------------------------------------------------
 * این کد را در script.google.com بچسبانید و به عنوان
 * «برنامه وب» منتشر کنید. راهنما: GSHEET.md
 *
 * امنیت: بدون توکن درست، هیچ نوشتنی انجام نمی شود.
 * آدرس برنامه وب قابل حدس نیست ولی مخفی هم نیست،
 * پس توکن لایه دوم دفاع است.
 */

// ⚠️ این را عوض کنید — یک رشته تصادفی بلند
var TOKEN = 'TOKEN_HERE';

var SHEET_NAME = 'journal';

var HEADERS = [
  'id', 'ts', 'asset', 'interval', 'price', 'score', 'conf',
  'grade', 'label', 'allowed', 'bucket', 'updates', 'checked',
  'outcome_r', 'outcome_status', 'parts_json', 'synced_at'
];


function doPost(e) {
  // قفل: دو نوشتن همزمان نباید سطرها را خراب کنند
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(25000);
  } catch (err) {
    return _json({ ok: false, error: 'قفل آزاد نشد' });
  }

  try {
    if (!e || !e.postData || !e.postData.contents) {
      return _json({ ok: false, error: 'بدنه خالی' });
    }

    var body = JSON.parse(e.postData.contents);

    if (!TOKEN || TOKEN === 'TOKEN_HERE') {
      return _json({ ok: false, error: 'توکن در اسکریپت تنظیم نشده' });
    }
    if (body.token !== TOKEN) {
      return _json({ ok: false, error: 'توکن نامعتبر' });
    }

    var rows = body.rows || [];
    if (!rows.length) return _json({ ok: true, created: 0, updated: 0 });

    var sheet = _sheet();

    // نگاشت id → شماره سطر، برای به روزرسانی به جای تکرار
    var lastRow = sheet.getLastRow();
    var index = {};
    if (lastRow > 1) {
      var ids = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
      for (var i = 0; i < ids.length; i++) {
        if (ids[i][0]) index[String(ids[i][0])] = i + 2;
      }
    }

    var created = 0, updated = 0;
    var appends = [];

    for (var j = 0; j < rows.length; j++) {
      var arr = _toRow(rows[j]);
      var id = String(rows[j].id || '');
      if (id && index[id]) {
        sheet.getRange(index[id], 1, 1, HEADERS.length).setValues([arr]);
        updated++;
      } else {
        appends.push(arr);
        created++;
      }
    }

    // نوشتن دسته ای — appendRow در حلقه کند است و سقف دارد
    if (appends.length) {
      sheet.getRange(sheet.getLastRow() + 1, 1,
                     appends.length, HEADERS.length).setValues(appends);
    }

    return _json({
      ok: true, created: created, updated: updated,
      total: sheet.getLastRow() - 1
    });

  } catch (err) {
    return _json({ ok: false, error: String(err).slice(0, 200) });
  } finally {
    lock.releaseLock();
  }
}


function doGet(e) {
  // بررسی سلامت — بدون توکن فقط می گوید زنده است
  var p = (e && e.parameter) || {};
  if (p.token !== TOKEN) {
    return _json({ ok: true, alive: true, authorized: false });
  }
  var sheet = _sheet();
  return _json({
    ok: true, alive: true, authorized: true,
    rows: Math.max(0, sheet.getLastRow() - 1),
    url: SpreadsheetApp.getActiveSpreadsheet().getUrl()
  });
}


function _sheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
  }
  if (sheet.getLastRow() === 0) {
    sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]);
    sheet.getRange(1, 1, 1, HEADERS.length).setFontWeight('bold');
    sheet.setFrozenRows(1);
  }
  return sheet;
}


function _toRow(r) {
  var o = r.outcome || {};
  return [
    r.id || '',
    r.ts || '',
    r.asset || '',
    r.interval || '',
    _num(r.price),
    _num(r.score),
    _num(r.conf),
    r.grade || '',
    r.label || '',
    r.allowed === true ? 'بله' : (r.allowed === false ? 'خیر' : ''),
    r.bucket || '',
    _num(r.updates),
    r.checked ? 'بله' : 'خیر',
    o.r_mult === undefined || o.r_mult === null ? '' : _num(o.r_mult),
    o.status || (r.checked ? '' : 'در انتظار'),
    JSON.stringify(r.parts || {}),
    new Date()
  ];
}


function _num(v) {
  if (v === undefined || v === null || v === '') return '';
  var n = Number(v);
  return isNaN(n) ? '' : n;
}


function _json(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
